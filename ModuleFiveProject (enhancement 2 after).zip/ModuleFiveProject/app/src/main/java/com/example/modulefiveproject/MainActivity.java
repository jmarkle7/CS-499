package com.example.modulefiveproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
// login screen class
public class MainActivity extends AppCompatActivity {

    //connect to database
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        // input
        EditText usernameInput = findViewById(R.id.editUsername);
        EditText passwordInput = findViewById(R.id.editPassword);

        // button
        Button loginButton = findViewById(R.id.btnLogin);
        Button createAccountButton = findViewById(R.id.btnCreate);

        createAccountButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();
            //input validation
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter a username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            // if username unique, create new account and store in database
            boolean created = db.createUser(username, password);
            if (created) {
                Toast.makeText(this, "Account created! Now log in.", Toast.LENGTH_SHORT).show();
                passwordInput.setText("");
            } else {
                Toast.makeText(this, "Username already exists.", Toast.LENGTH_SHORT).show();
            }
        });

        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter a username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            // validate login credentials are correct
            boolean valid = db.validateLogin(username, password);
            if (valid) {
                Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();

                // after login, send user to SMS screen
                startActivity(new Intent(this, SmsActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Invalid login.", Toast.LENGTH_SHORT).show();
                passwordInput.setText("");
            }
        });
    }
}