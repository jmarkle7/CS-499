package com.example.modulefiveproject;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

//class for weight log screen
public class DataScreenActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private TableLayout tableWeightLog;
    private TextView tvWeeklyAverage;
    private TextView tvTrend;

    // Data structure used for the weekly trend analysis enhancement
    private static class WeightEntry {
        String date;
        double weight;

        WeightEntry(String date, double weight) {
            this.date = date;
            this.weight = weight;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datascreen);

        db = new DatabaseHelper(this);
        tableWeightLog = findViewById(R.id.tableWeightLog);
        tvWeeklyAverage = findViewById(R.id.tvWeeklyAverage);
        tvTrend = findViewById(R.id.tvTrend);

        Button btnAddEntry = findViewById(R.id.btnAddEntry);
        btnAddEntry.setOnClickListener(v -> showAddEntryDialog());

        Button btnGoalTracking = findViewById(R.id.btnGoalTracking);
        btnGoalTracking.setOnClickListener(v -> {
            Intent intent = new Intent(this, GoalTrackingActivity.class);
            startActivity(intent);
        });

        refreshTable();
    }

    //refresh data table from database
    private void refreshTable() {

        int childCount = tableWeightLog.getChildCount();
        if (childCount > 1) {
            tableWeightLog.removeViews(1, childCount - 1);
        }

        ArrayList<WeightEntry> entries = new ArrayList<>();

        Cursor cursor = db.getAllWeightEntries();

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_WEIGHT_ID));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_DATE));
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_WEIGHT));
            int goalReachedInt = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_GOAL_REACHED));
            boolean goalReached = (goalReachedInt == 1);

            entries.add(new WeightEntry(date, weight));

            TableRow row = new TableRow(this);

            TextView tvDate = new TextView(this);
            tvDate.setText(date);
            tvDate.setPadding(8, 8, 8, 8);

            TextView tvWeight = new TextView(this);
            tvWeight.setText(String.valueOf(weight));
            tvWeight.setPadding(8, 8, 8, 8);

            TextView tvGoal = new TextView(this);
            tvGoal.setText(goalReached ? "Yes" : "No");
            tvGoal.setPadding(8, 8, 8, 8);

            Button btnDelete = new Button(this);
            btnDelete.setText("Delete");
            btnDelete.setAllCaps(false);
            btnDelete.setOnClickListener(v -> {
                db.deleteWeightEntry(id);
                refreshTable();
            });

            row.setOnClickListener(v -> showEditEntryDialog(id, date, weight));

            row.addView(tvDate);
            row.addView(tvWeight);
            row.addView(tvGoal);
            row.addView(btnDelete);

            tableWeightLog.addView(row, new TableLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
            ));
        }

        cursor.close();

        calculateWeeklyTrend(entries);
    }

    // Calculates weekly averages and compares the most recent week to the previous week
    private void calculateWeeklyTrend(ArrayList<WeightEntry> entries) {

        if (entries.size() < 2) {
            tvWeeklyAverage.setText("Weekly Average: Not enough data");
            tvTrend.setText("Trend: N/A");
            return;
        }

        HashMap<Integer, ArrayList<Double>> weeklyGroups = new HashMap<>();

        int week = 1;

        for (WeightEntry entry : entries) {

            if (!weeklyGroups.containsKey(week)) {
                weeklyGroups.put(week, new ArrayList<>());
            }

            weeklyGroups.get(week).add(entry.weight);

            if (weeklyGroups.get(week).size() == 7) {
                week++;
            }
        }

        double previousAverage = 0;
        double currentAverage = 0;

        for (Map.Entry<Integer, ArrayList<Double>> group : weeklyGroups.entrySet()) {

            double total = 0;

            for (Double weight : group.getValue()) {
                total += weight;
            }

            double average = total / group.getValue().size();

            previousAverage = currentAverage;
            currentAverage = average;
        }

        tvWeeklyAverage.setText(
                "Weekly Average: " +
                        String.format("%.2f", currentAverage) +
                        " lbs"
        );

        if (previousAverage == 0) {
            tvTrend.setText("Trend: N/A");
        } else if (currentAverage < previousAverage) {
            tvTrend.setText("Trend: Positive");
        } else {
            tvTrend.setText("Trend: Negative");
        }
    }

    //method to add entry to weight table and update database
    private void showAddEntryDialog() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Weight Entry");

        ViewGroup layout = new android.widget.LinearLayout(this);
        ((android.widget.LinearLayout) layout).setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = 32;
        layout.setPadding(pad, pad, pad, pad);

        EditText etDate = new EditText(this);
        etDate.setHint("Date (MM/DD/YYYY)");

        EditText etWeight = new EditText(this);
        etWeight.setHint("Weight (lbs)");
        etWeight.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        EditText etGoal = new EditText(this);
        etGoal.setHint("Goal weight (optional)");
        etGoal.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        layout.addView(etDate);
        layout.addView(etWeight);
        layout.addView(etGoal);

        builder.setView(layout);

        builder.setPositiveButton("Save", (dialog, which) -> {

            String date = etDate.getText().toString().trim();
            String weightStr = etWeight.getText().toString().trim();
            String goalStr = etGoal.getText().toString().trim();

            if (date.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this, "Date and weight are required.", Toast.LENGTH_SHORT).show();
                return;
            }

            double weight = Double.parseDouble(weightStr);

            Double goal = null;
            if (!goalStr.isEmpty()) {
                goal = Double.parseDouble(goalStr);
            }

            db.insertWeightEntry(date, weight, goal);
            refreshTable();

            checkAndSendGoalSms(weight, goal);
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    //method to edit an entry and update in database
    private void showEditEntryDialog(long id, String oldDate, double oldWeight) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Entry");

        ViewGroup layout = new android.widget.LinearLayout(this);
        ((android.widget.LinearLayout) layout).setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = 32;
        layout.setPadding(pad, pad, pad, pad);

        EditText etDate = new EditText(this);
        etDate.setText(oldDate);

        EditText etWeight = new EditText(this);
        etWeight.setText(String.valueOf(oldWeight));
        etWeight.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        EditText etGoal = new EditText(this);
        etGoal.setHint("Goal weight (optional)");
        etGoal.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        layout.addView(etDate);
        layout.addView(etWeight);
        layout.addView(etGoal);

        builder.setView(layout);

        builder.setPositiveButton("Update", (dialog, which) -> {

            String date = etDate.getText().toString().trim();
            String weightStr = etWeight.getText().toString().trim();
            String goalStr = etGoal.getText().toString().trim();

            if (date.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this, "Date and weight are required.", Toast.LENGTH_SHORT).show();
                return;
            }

            double weight = Double.parseDouble(weightStr);

            Double goal = null;
            if (!goalStr.isEmpty()) {
                goal = Double.parseDouble(goalStr);
            }

            db.updateWeightEntry(id, date, weight, goal);
            refreshTable();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    //method to check if weight goal is reached and send SMS if user has enabled
    private void checkAndSendGoalSms(double weight, Double goal) {

        if (goal == null) return;
        if (weight > goal) return;

        SharedPreferences prefs =
                getSharedPreferences("app_prefs", MODE_PRIVATE);

        boolean smsEnabled = prefs.getBoolean("sms_enabled", false);
        if (!smsEnabled) return;

        try {
            SmsManager smsManager = SmsManager.getDefault();

            String phoneNumber = "5551234567";

            smsManager.sendTextMessage(
                    phoneNumber,
                    null,
                    "Congrats! You reached your goal weight!",
                    null,
                    null
            );

            Toast.makeText(this,
                    "Goal reached! SMS sent.",
                    Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            Toast.makeText(this,
                    "SMS failed to send.",
                    Toast.LENGTH_SHORT).show();
        }
    }
}