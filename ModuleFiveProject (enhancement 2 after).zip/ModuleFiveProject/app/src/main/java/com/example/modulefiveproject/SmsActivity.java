package com.example.modulefiveproject;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

// sms screen class
public class SmsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;
    private static final String PREFS = "app_prefs";
    private static final String KEY_SMS_ENABLED = "sms_enabled";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_screen);

        Button acceptButton = findViewById(R.id.btnAcceptSms);
        Button denyButton = findViewById(R.id.btnDenySms);

        // when user clicks accept, prompt phone to enable sms permissions
        acceptButton.setOnClickListener(v -> requestSmsPermission());

        // user denies notifications and is sent to weight log screen
        denyButton.setOnClickListener(v -> {
            saveSmsPreference(false);
            navigateToDataScreen();
        });
    }

   //method to request permisson on device
    private void requestSmsPermission() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );

        } else {
            // Permission already granted
            saveSmsPreference(true);
            navigateToDataScreen();
        }
    }
    //handles user's response
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this,
                        "SMS permission granted.",
                        Toast.LENGTH_SHORT).show();

                saveSmsPreference(true);

            } else {

                Toast.makeText(this,
                        "SMS permission denied.",
                        Toast.LENGTH_SHORT).show();

                saveSmsPreference(false);
            }

            navigateToDataScreen();
        }
    }

    //saves SMS preferance for next login
    private void saveSmsPreference(boolean enabled) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_SMS_ENABLED, enabled).apply();
    }

   //move to weight log screen
    private void navigateToDataScreen() {
        startActivity(new Intent(this, DataScreenActivity.class));
        finish();
    }
}