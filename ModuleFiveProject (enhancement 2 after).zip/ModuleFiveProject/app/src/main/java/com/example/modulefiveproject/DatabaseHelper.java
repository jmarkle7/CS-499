package com.example.modulefiveproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DatabaseHelper extends SQLiteOpenHelper {
    //login credentials table
    private static final String DB_NAME = "weight_tracker.db";
    private static final int DB_VERSION = 2;
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD_HASH = "password_hash";
    //weight data table
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COL_WEIGHT_ID = "id";
    public static final String COL_DATE = "date";
    public static final String COL_WEIGHT = "weight";
    public static final String COL_GOAL_WEIGHT = "goal_weight";
    public static final String COL_GOAL_REACHED = "goal_reached"; // 0/1

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    //creates database tables
    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsers =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_USERNAME + " TEXT UNIQUE NOT NULL, " +
                        COL_PASSWORD_HASH + " TEXT NOT NULL" +
                        ");";

        String createWeights =
                "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                        COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COL_DATE + " TEXT NOT NULL, " +
                        COL_WEIGHT + " REAL NOT NULL, " +
                        COL_GOAL_WEIGHT + " REAL, " +
                        COL_GOAL_REACHED + " INTEGER NOT NULL DEFAULT 0" +
                        ");";

        db.execSQL(createUsers);
        db.execSQL(createWeights);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }

    //create user method
    public boolean createUser(String username, String passwordPlainText) {
        String hash = sha256(passwordPlainText);

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username.trim());
        values.put(COL_PASSWORD_HASH, hash);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean validateLogin(String username, String passwordPlainText) {
        String hash = sha256(passwordPlainText);

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT " + COL_USER_ID +
                " FROM " + TABLE_USERS +
                " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD_HASH + "=?";

        Cursor cursor = db.rawQuery(sql, new String[]{username.trim(), hash});
        boolean success = cursor.moveToFirst();
        cursor.close();
        return success;
    }


    //crud methods to maintain weight log
    public long insertWeightEntry(String date, double weight, Double goalWeight) {
        boolean goalReached = (goalWeight != null && weight <= goalWeight);

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_DATE, date);
        values.put(COL_WEIGHT, weight);

        if (goalWeight != null) values.put(COL_GOAL_WEIGHT, goalWeight);
        else values.putNull(COL_GOAL_WEIGHT);

        values.put(COL_GOAL_REACHED, goalReached ? 1 : 0);

        return db.insert(TABLE_WEIGHTS, null, values);
    }

    public Cursor getAllWeightEntries() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_WEIGHTS,
                null,
                null,
                null,
                null,
                null,
                COL_DATE + " DESC"
        );
    }

    public double getStartingWeight() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_WEIGHTS,
                null,
                null,
                null,
                null,
                null,
                COL_WEIGHT_ID + " ASC",
                "1"
        );

        double weight = -1;
        if (cursor.moveToFirst()) {
            weight = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_WEIGHT));
        }

        cursor.close();
        return weight;
    }

    public double getCurrentWeight() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_WEIGHTS,
                null,
                null,
                null,
                null,
                null,
                COL_WEIGHT_ID + " DESC",
                "1"
        );

        double weight = -1;
        if (cursor.moveToFirst()) {
            weight = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_WEIGHT));
        }

        cursor.close();
        return weight;
    }

    public double getGoalWeight() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_WEIGHTS,
                null,
                COL_GOAL_WEIGHT + " IS NOT NULL",
                null,
                null,
                null,
                COL_WEIGHT_ID + " DESC",
                "1"
        );

        double goal = -1;
        if (cursor.moveToFirst()) {
            goal = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_GOAL_WEIGHT));
        }

        cursor.close();
        return goal;
    }

    public int updateWeightEntry(long id, String date, double weight, Double goalWeight) {
        boolean goalReached = (goalWeight != null && weight <= goalWeight);

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_DATE, date);
        values.put(COL_WEIGHT, weight);

        if (goalWeight != null) values.put(COL_GOAL_WEIGHT, goalWeight);
        else values.putNull(COL_GOAL_WEIGHT);

        values.put(COL_GOAL_REACHED, goalReached ? 1 : 0);

        return db.update(TABLE_WEIGHTS, values, COL_WEIGHT_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    public int deleteWeightEntry(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(TABLE_WEIGHTS, COL_WEIGHT_ID + "=?",
                new String[]{String.valueOf(id)});
    }


    private String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(input.getBytes());

            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();

        } catch (NoSuchAlgorithmException e) {
            return String.valueOf(input.hashCode());
        }
    }
}