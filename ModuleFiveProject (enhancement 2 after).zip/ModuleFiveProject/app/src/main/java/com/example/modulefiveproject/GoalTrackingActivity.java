package com.example.modulefiveproject;

import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

// class for Goal Tracking screen
public class GoalTrackingActivity extends AppCompatActivity {

    // database helper object
    private DatabaseHelper db;

    // UI components
    private ProgressBar progressBar;
    private TextView txtProgress;
    private TextView txtMessage;
    private TextView txtStats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal_tracking);

        // connect database helper
        db = new DatabaseHelper(this);

        // connect UI elements to XML components
        progressBar = findViewById(R.id.progressGoal);
        txtProgress = findViewById(R.id.txtProgress);
        txtMessage = findViewById(R.id.txtMessage);
        txtStats = findViewById(R.id.txtStats);

        // calculate and display user progress
        calculateProgress();
    }

    // method to calculate progress toward goal weight
    private void calculateProgress() {

        // retrieve weight data from database
        double startingWeight = db.getStartingWeight();
        double currentWeight = db.getCurrentWeight();
        double goalWeight = db.getGoalWeight();

        // validate required data exists
        if (startingWeight == -1 || currentWeight == -1 || goalWeight == -1) {

            txtMessage.setText(
                    "Add a starting weight, current weight, and goal weight to view progress."
            );

            progressBar.setProgress(0);
            txtProgress.setText("0%");
            txtStats.setText("");

            return;
        }

        double totalProgress;
        double currentProgress;

        // logic for weight loss goal
        if (goalWeight < startingWeight) {

            totalProgress = startingWeight - goalWeight;
            currentProgress = startingWeight - currentWeight;

        } else {

            // logic for weight gain goal
            totalProgress = goalWeight - startingWeight;
            currentProgress = currentWeight - startingWeight;
        }

        // prevent divide-by-zero errors
        if (totalProgress == 0) {

            txtMessage.setText(
                    "Your starting weight and goal weight cannot be the same."
            );

            progressBar.setProgress(0);
            txtProgress.setText("0%");

            return;
        }

        // calculate progress percentage
        int progressPercentage =
                (int) ((currentProgress / totalProgress) * 100);

        // prevent progress over 100%
        if (progressPercentage > 100) {
            progressPercentage = 100;
        }

        // prevent negative progress
        if (progressPercentage < 0) {
            progressPercentage = 0;
        }

        // update progress bar and percentage text
        progressBar.setProgress(progressPercentage);
        txtProgress.setText(progressPercentage + "% Complete");

        // calculate remaining weight difference
        double poundsRemaining =
                Math.abs(currentWeight - goalWeight);

        // display statistics for user
        txtStats.setText(
                "Starting Weight: " + startingWeight + " lbs\n" +
                        "Current Weight: " + currentWeight + " lbs\n" +
                        "Goal Weight: " + goalWeight + " lbs\n" +
                        "Pounds Remaining: " + poundsRemaining + " lbs"
        );

        // display dynamic progress message
        if (progressPercentage >= 100) {

            txtMessage.setText(
                    "Congratulations! You reached your weight goal."
            );

        } else if (progressPercentage > 0) {

            txtMessage.setText(
                    "Great job! You are making progress toward your goal."
            );

        } else {

            txtMessage.setText(
                    "You have not made progress yet. Stay disciplined and keep going."
            );
        }
    }
}