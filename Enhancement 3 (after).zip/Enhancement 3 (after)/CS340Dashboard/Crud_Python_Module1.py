# Example Python Code to Insert a Document 

from pymongo import MongoClient 
from bson.objectid import ObjectId 
from pymongo.errors import PyMongoError #error import

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password):
        # Connection Variables
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

    # Initialize Connection using passed-in credentials
        self.client = MongoClient(
            f"mongodb://{username}:{password}@{HOST}:{PORT}/{DB}?authSource=admin"
    )
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        #validate input
        if data is None or not isinstance(data, dict):
            return False
        try:
            #insert using the collection 
            result = self.collection.insert_one(data)  
            return result.acknowledged 
        #return false if error creating
        except PyMongoError:
            return False

    # Create method to implement the R in CRUD.
    def read(self, query):
        #read all documents if query is none
        if query is None:
            query = {}
        #input validation for key/value pair
        if not isinstance(query, dict):
            return []
        #return result in list
        try:
            cursor = self.collection.find(query)  
            return list(cursor)   
        #empty list if theres an error
        except PyMongoError:
            return []
        # Update method to impliment the U in CRUD
    def update(self, query, new_values, multiple=False):
        if not isinstance(query, dict) or not isinstance(new_values, dict):
            return 0
        try:
            if multiple:
                result = self.collection.update_many(query, {'$set': new_values})
            else:
                result = self.collection.update_one(query, {'$set': new_values})
            return result.modified_count
        except PyMongoError:
            return 0
        # Delete method to impliment the D in CRUD
    def delete(self, query, multiple=False):
        if not isinstance(query, dict):
            return 0
        try:
            if multiple:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
            return result.deleted_count
        except PyMongoError:
            return 0
    