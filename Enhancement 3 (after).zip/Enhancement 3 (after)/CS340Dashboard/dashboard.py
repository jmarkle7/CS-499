import dash_leaflet as dl
from dash import Dash, dcc, html, dash_table
import plotly.express as px
from dash.dependencies import Input, Output
import pandas as pd

# Load the animal shelter dataset
df = pd.read_csv("aac_shelter_outcomes.csv")

print("RUNNING ENHANCED CS-499 DASHBOARD")

animal_type_options = sorted(df["animal_type"].dropna().unique())
sex_options = sorted(df["sex_upon_outcome"].dropna().unique())

# Initialize the Dash application.
app = Dash(__name__)


app.layout = html.Div([

    html.Center(html.H1("CS-340 Dashboard")),
    html.Center(html.H3("Jaydon Markle")),

    html.Hr(),

    html.H2("Grazioso Salvare Advanced Rescue Dashboard"),

    # Rescue type filter.
    html.Label("Rescue Type"),
    dcc.RadioItems(
        id="filter-type",
        options=[
            {"label": "Reset (All)", "value": "RESET"},
            {"label": "Water Rescue", "value": "WATER"},
            {"label": "Mountain/Wilderness Rescue", "value": "MOUNTAIN"},
            {"label": "Disaster/Tracking", "value": "DISASTER"},
        ],
        value="RESET",
        inline=True
    ),

    html.Br(),

    # Breed filter.
    html.Label("Breed Search"),
    dcc.Input(
        id="breed-filter",
        type="text",
        placeholder="Example: Husky",
        debounce=True
    ),

    html.Br(),
    html.Br(),

    # Age filter.
    html.Label("Age in Weeks"),
    dcc.Input(
        id="age-filter",
        type="number",
        placeholder="Example: 52",
        debounce=True
    ),

    html.Br(),
    html.Br(),

    # Sex filter.
    html.Label("Sex"),
    dcc.Dropdown(
        id="sex-filter",
        options=[{"label": sex, "value": sex} for sex in sex_options],
        placeholder="Select sex",
        clearable=True
    ),

    html.Br(),

    # Animal type filter.
    html.Label("Animal Type"),
    dcc.Dropdown(
        id="animal-type-filter",
        options=[{"label": animal, "value": animal} for animal in animal_type_options],
        placeholder="Select animal type",
        clearable=True
    ),

    html.Hr(),


    html.H3(id="match-count"),

    # Data table.
    dash_table.DataTable(
        id="datatable-id",
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict("records"),
        page_size=10,
        sort_action="native",
        filter_action="native",
        row_selectable="single",
        selected_rows=[0],
        style_table={"overflowX": "auto"},
        style_cell={
            "textAlign": "left",
            "minWidth": "120px",
            "width": "120px",
            "maxWidth": "180px"
        }
    ),

    html.Br(),
    html.Hr(),

    # Graph and map display.
    html.Div(
        style={"display": "flex"},
        children=[
            html.Div(id="graph-id", style={"width": "50%"}),
            html.Div(id="map-id", style={"width": "50%"})
        ]
    )
])


# Filter Callback
@app.callback(
    [
        Output("datatable-id", "data"),
        Output("match-count", "children")
    ],
    [
        Input("filter-type", "value"),
        Input("breed-filter", "value"),
        Input("age-filter", "value"),
        Input("sex-filter", "value"),
        Input("animal-type-filter", "value")
    ]
)
def update_dashboard(filter_type, breed_filter, age_filter, sex_filter, animal_type_filter):

    
    df2 = df.copy()


    if filter_type == "WATER":

        breeds = [
            "Labrador Retriever Mix",
            "Chesapeake Bay Retriever",
            "Newfoundland"
        ]

        df2 = df2[
            (df2["animal_type"] == "Dog") &
            (df2["breed"].isin(breeds))
        ]

    elif filter_type == "MOUNTAIN":

        breeds = [
            "German Shepherd",
            "German Shepherd Mix",
            "Alaskan Malamute",
            "Alaskan Malamute Mix",
            "Old English Sheepdog",
            "Old English Sheepdog Mix",
            "Siberian Husky",
            "Siberian Husky Mix",
            "Rottweiler",
            "Rottweiler Mix"
        ]

        df2 = df2[
            (df2["animal_type"] == "Dog") &
            (df2["breed"].isin(breeds))
        ]

    elif filter_type == "DISASTER":

        breeds = [
            "Doberman Pinscher",
            "Doberman Pinscher Mix",
            "German Shepherd",
            "German Shepherd Mix",
            "Golden Retriever",
            "Golden Retriever Mix",
            "Bloodhound",
            "Bloodhound Mix",
            "Rottweiler",
            "Rottweiler Mix"
        ]

        df2 = df2[
            (df2["animal_type"] == "Dog") &
            (df2["breed"].isin(breeds))
        ]

    # Breed search filter.
    if breed_filter:
        df2 = df2[df2["breed"].str.contains(breed_filter, case=False, na=False)]

    # Age filter.
    if age_filter is not None and "age_upon_outcome_in_weeks" in df2.columns:
        df2 = df2[
            df2["age_upon_outcome_in_weeks"].round() == age_filter
        ]

    # Sex filter.
    if sex_filter:
        df2 = df2[df2["sex_upon_outcome"] == sex_filter]

    # Animal type filter.
    if animal_type_filter:
        df2 = df2[df2["animal_type"] == animal_type_filter]

    # Create a count message so users can see how many animals match.
    count_message = f"Matching Animals: {len(df2)}"

    # Return the filtered records to the table and the count to the page.
    return df2.to_dict("records"), count_message


# GRAPH CALLBACK
@app.callback(
    Output("graph-id", "children"),
    Input("datatable-id", "derived_virtual_data")
)
def update_graphs(viewData):

  
    if viewData is None:
        return []

    dff = pd.DataFrame(viewData)

    if dff.empty or "breed" not in dff.columns:
        return [html.P("No breed data available for this filter.")]

    breed_counts = dff["breed"].value_counts().head(10)

    fig = px.bar(
        x=breed_counts.index,
        y=breed_counts.values,
        labels={"x": "Breed", "y": "Count"},
        title="Top 10 Breeds"
    )

    return [dcc.Graph(figure=fig)]


# MAP CALLBACK
@app.callback(
    Output("map-id", "children"),
    [
        Input("datatable-id", "derived_virtual_data"),
        Input("datatable-id", "selected_rows")
    ]
)
def update_map(viewData, selected_rows):

    if viewData is None:
        return []

    dff = pd.DataFrame(viewData)

    if dff.empty:
        return [html.P("No results for this filter.")]

    lat_col = "location_lat"
    lon_col = "location_long"

    if lat_col not in dff.columns or lon_col not in dff.columns:
        return [html.P("Latitude/Longitude columns missing.")]


    dff[lat_col] = pd.to_numeric(dff[lat_col], errors="coerce")
    dff[lon_col] = pd.to_numeric(dff[lon_col], errors="coerce")

    dff = dff.dropna(subset=[lat_col, lon_col])

    if dff.empty:
        return [html.P("No valid coordinates available.")]

    row = 0

    if selected_rows and len(selected_rows) > 0:
        row = selected_rows[0]

    
    if row >= len(dff):
        row = 0

    lat = float(dff.iloc[row][lat_col])
    lon = float(dff.iloc[row][lon_col])

    breed = str(dff.iloc[row]["breed"]) if "breed" in dff.columns else "Animal"

    return [
        dl.Map(
            style={"width": "100%", "height": "500px"},
            center=[lat, lon],
            zoom=10,
            children=[

                dl.TileLayer(),

                dl.Marker(
                    position=[lat, lon],
                    children=[
                        dl.Tooltip(breed)
                    ]
                )
            ]
        )
    ]



app.run(host="127.0.0.1", port=8050, debug=False)